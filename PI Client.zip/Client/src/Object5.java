// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public final class Object5
{

	public Object5()
	{
	}

	int anInt517;
	int anInt518;
	int anInt519;
	int anInt520;
	public Animable aClass30_Sub2_Sub4_521;
	public int anInt522;
	int anInt523;
	int anInt524;
	int anInt525;
	int anInt526;
	int anInt527;
	int anInt528;
	public int uid;
	byte aByte530;
}
