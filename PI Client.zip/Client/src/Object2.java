// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public final class Object2
{

	public Object2()
	{
	}

	int anInt499;
	int anInt500;
	int anInt501;
	int anInt502;
	int anInt503;
	public Animable aClass30_Sub2_Sub4_504;
	public int uid;
	byte aByte506;
}
